
<p><h1 align="center">Add Client</h1></p>
  <form method="post" action="addclient1.php">
    Last Name:
    <input type="text" name="lname" class="form-control" required="required" />
   
    First Name:
    <input type="text" name="fname" class="form-control" required="required"/>
   
    Meter Number:
    <input type="text" name="mi" class="form-control" required="required"/>
   Address:
    <input type="text" name="address" class="form-control" required="required"/>
    Contact #:<input type="text" name="contact"  class="form-control" required="required"/>
    First Meter Reading:
    <input type="text" name="meterReader" class="form-control" required="required"/>
    <br />
    <input type="submit" name="add" value="ADD"  class="btn btn-success form-control"/>
  
 

</form>

